from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from django.urls.conf import include
from DeliveryTeam  import views
from rest_framework.schemas import get_schema_view
import drf_yasg.views as yasg_view
from drf_yasg import openapi
from ajax_select import urls as ajax_select_urls
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

schema_view = yasg_view.get_schema_view(
   openapi.Info(
      title="Care-Box-Backend",
      default_version='v1',
      description="Documentation for Care-Box-Backend",
      terms_of_service="https://www.google.com/policies/terms/",
      contact=openapi.Contact(email="contact@snippets.local"),
      license=openapi.License(name="BSD License"),
   ),
   public=True,
)

urlpatterns = [
    path('ajax_select/', include(ajax_select_urls)),
    path('admin/', admin.site.urls),
    path('api/v1/upload_prescription/', include('upload_prescription_api.urls')),
    path('api/v1/product/', include('product.urls')),
    # path('api/v1/DeliveryTeam/',views.ListofDeliveryTeam,name="DeliveryBoy"), 
    path('api/v1/DeliveryTeam/',include('DeliveryTeam.urls')),
    path('api/v1/payment/',include('payment.urls')),
    path('api/user/', include('user_api.urls', namespace='users')),
    path('api/v1/header_content/', include('header_content.urls')),
    path('api/v1/slider_image/', include('slider_image.urls')),
    path('api/v1/blog_content/',include('blog.urls')),
    path('api/v1/docapp/',include('Doctor_appointment.urls')),
    path('api/v2/chatbot/', include('simple_chatbot.urls')),
    path('api/v2/career/', include('career.urls')),
    path('dashboard/', include('dashboard.urls')),
    path('carebox-schema/', get_schema_view(
        title="Care-Box-Backend",
        description="API for Care-Box-Backend",
        version="1.0.0"
    ), name='openapi-schema'),
    path('carebox-swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

#sifat