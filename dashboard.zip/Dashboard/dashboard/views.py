from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .forms import LoginForm
from django import template
from datetime import  datetime
from django.utils.timezone import get_current_timezone
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
import datetime
from django.utils import timezone
from product.models import  Orderplaced
from Doctor_appointment.models import  Appointment, Attandance
from django.db.models import Q

from django.db.models import Sum
from product.models import Orderplaced
from Doctor_appointment.models import Doctor

import json

from .fusioncharts import FusionCharts



def login_view(request):
    form = LoginForm(request.POST or None)

    msg = None

    if request.method == "POST":

        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)

            if user and not user.is_superuser:
                msg = 'You are not authorized'

            elif user is not None:
                login(request, user)
                return redirect(reverse("home"))
            else:
                msg = 'Invalid credentials'
        else:
            msg = 'Error validating the form'

    return render(request, "accounts/login.html", {"form": form, "msg": msg})

 
@login_required(login_url="/dashboard/login/")
def logout_view(request):
    logout(request)
    return redirect('login')


@login_required(login_url="/dashboard/login/")
def doctortemplate(request):
    context = {'segment': 'index'}
    print(request.POST)
    if request.method == 'POST':
        fromdata = request.POST.get('fromdate','')
         
        print(request.GET)
        todata  =  request.POST.get('todate','')
        print("my data",fromdata)
        select = request.POST.get('select','')
        print("select", select)
        #searchresult =EmployeeModel.objects.raw(select )
        
        context['doctor_count']=  Attandance.objects.filter( Q(Name=select) &
          Q(createdAt__gte=fromdata) & 
            Q(createdAt__lte=todata) 
        ).count()
        context['patient_count'] = Appointment.objects.filter( Q(createdAt__gte=fromdata) & 
            Q(createdAt__lte=todata) &  Q(DoctorName=select)   
        ).count() 
        context['doctor_schedule'] = Doctor.objects.get(Id=select).Time
        context['doctor_name'] = Doctor.objects.get(Id=select).Name
        
    html_template = loader.get_template('home/doctorcount.html') 
    doctors = Doctor.objects.all()
    context["doctors"] = doctors  
    
    
    return HttpResponse(html_template.render(context,request))


@login_required(login_url="/dashboard/login/")
def index(request):
    context = {'segment': 'context'}
    
    data = None
    total_order_volume = None
    
    if  request.method == 'POST':
       
        fromdata = request.POST.get('fromdate','')
        todata=  request.POST.get('todate','')
        
        #print("my date:",fromdata)
        #print("next date", todata)
        data = Orderplaced.objects.filter(
            Q(createdAt__gte=fromdata) & 
            Q(createdAt__lte=todata) &
            Q(
                Q(order_status = 'delivered') |
                Q(order_status = 'confirmed')
            ) 
        ).count()

        total_order_volume = (
            Orderplaced.objects.filter(
                Q(createdAt__gte=fromdata) &
                Q(createdAt__lte=todata) &
                Q(
                    Q(order_status = 'delivered') |
                    Q(order_status = 'confirmed')
                )
            ).aggregate(Sum('totalPrice'))
        )['totalPrice__sum']

        if not total_order_volume:
            total_order_volume = 0.0

        request.session['data'] = data
        request.session['total_order_volume'] = float(total_order_volume)
        request.session.modified = True
        return redirect('home')
    else:
        data = Orderplaced.objects.filter(
            Q(order_status = 'delivered') |
            Q(order_status = 'confirmed')
        ).count()

        total_order_volume = (
            Orderplaced.objects.filter(
                Q(order_status = 'delivered') |
                Q(order_status = 'confirmed')
            ).aggregate(Sum('totalPrice'))
        )['totalPrice__sum']

    if 'data' in  request.session:
        data = request.session['data']
        total_order_volume = request.session['total_order_volume']
        del request.session['data']
        del request.session['total_order_volume']

    context['total_orders'] =  data
    context['total_order_volume'] = total_order_volume



    # Chart
    li = []

    Month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun ', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

    for i in range(1,13):
        p = (Orderplaced.objects.filter(

            Q(createdAt__month__gte = i) &
            Q(createdAt__month__lte = i) &
            Q(
                Q(order_status = 'delivered') |
                Q(order_status = 'confirmed')
            )  
        ).aggregate(Sum('totalPrice')))['totalPrice__sum']
        t = dict()
        

        sale = Orderplaced.objects.filter(
            Q(createdAt__month__gte = i) &
            Q(createdAt__month__lte = i) &
            Q(
                Q(order_status = 'delivered') |
                Q(order_status = 'confirmed')
            )
        ).count()

        if sale > 0:
            Month[i-1] = Month[i-1] + f" Sales:{sale}"

        t["label"] = Month[i-1]

        if not p:
            t["value"] = 0
        else:
            t["value"] = float(p)

        li.append(t)




    obj = {
             "chart":
             {
                "caption": "Total amount of sale per month",
                "subCaption": "In Bangladeshi Taka",
                "xAxisName": "Month",
                "yAxisName": "Total Amount(Taka)",
                "numberSuffix": " TK",
                "theme": "fusion"
             },
        }
    obj["data"] = li

    string_data = json.dumps(obj)

    # Create an object for the column2d chart using the FusionCharts class constructor
    column2d = FusionCharts("column2d", "ex1", '100%', '450', "chart-1", "json",
        # The chart data is passed as a string to the `dataSource` parameter.
        string_data)

    # Attach event with method name, and the callee method defined in html page.
    column2d.addEvent("dataplotClick", "onDataplotClick")

    context['output'] = column2d.render()
    context['chartTitle'] = 'Interactive sales overview'
   

    html_template = loader.get_template('home/index.html')
    return HttpResponse(html_template.render(context,request))
    


    
     





@login_required(login_url="/dashboard/login/")
def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:

        load_template = request.path.split('/')[-1]

        if load_template == 'admin':
            return HttpResponseRedirect(reverse('admin:index'))
        context['segment'] = load_template

        html_template = loader.get_template('home/' + load_template)
        return HttpResponse(html_template.render(context, request))

    except template.TemplateDoesNotExist:

        html_template = loader.get_template('home/page-404.html')
        return HttpResponse(html_template.render(context, request))

    except:
        html_template = loader.get_template('home/page-500.html')
        return HttpResponse(html_template.render(context, request))

   
      ####   Dashboard  doctor part

  

