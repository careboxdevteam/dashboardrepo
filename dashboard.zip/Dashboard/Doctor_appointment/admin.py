from django.contrib import admin
from .models import Doctor, Appointment, Attandance


class Doctor_Admin(admin.ModelAdmin):
    #fields = ('Name','Designation','Time','Active',)
    list_display = ('Id','Name','Designation','Time','Active',)
    list_filter = ('Time','Active',)

class Appointment_Admin(admin.ModelAdmin):
    #fields = ('Patient_name','Mobile_number','createdAt')
    list_display = ('Id','Patient_name','DoctorName','Mobile_number','createdAt')
    list_filter = ('DoctorName',)

class Doctor_Attandance_admin(admin.ModelAdmin):
    #fields = ('Name','Designation','Time','Active',)
    list_display = ('id','Name','createdAt')
    list_filter = ('id','Name')

admin.site.register( Doctor, Doctor_Admin )
admin.site.register( Appointment, Appointment_Admin ) 
admin.site.register( Attandance, Doctor_Attandance_admin)   