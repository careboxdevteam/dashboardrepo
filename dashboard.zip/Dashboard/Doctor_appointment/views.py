from django.db.models.query import QuerySet
from django.shortcuts import render
from .models import Doctor, Appointment
from .serializers import Doctor_serializers, Appointment_serializer
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from rest_framework.viewsets import ViewSet
from django.conf import settings
from rest_framework.permissions import IsAuthenticated
from rest_framework.reverse import reverse
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework import status
from django.shortcuts import get_list_or_404, render 
from rest_framework.decorators import api_view
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views import generic 
from django.db.models import When, Case, F, IntegerField 

# Create your views here.
'''
class AppoinmentListView(generics.ListCreateView):
    
    queryset = Doctor.objects.all().filter(Name=1)
    permission_classes = [IsAuthenticated]
    def list(self, request):
        # Note the use of `get_queryset()` instead of `self.queryset`
        queryset = self.get_queryset()
        serializer =  Appointment_serializer(queryset, many=True)
        return Response(serializer.data)
'''

class DoctorsView(generics.ListAPIView):
    queryset = Doctor.objects.all().filter(Active = 'Yes')
    serializer_class = Appointment_serializer

class AppointmentView(APIView):
     
    def post(self, request,format=None):
        if 'Custom-User-Agent' in request.headers and request.headers['Custom-User-Agent']==settings.CUSTOMHEADER:
            #queryset = Appointment.objects.all()
            serializer = Appointment_serializer(data=request.data)
            if serializer.is_valid():
                 serializer.save()
                 return Response(serializer.data,status=status.HTTP_201_CREATED)

            return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

        return Response({"Failure": "Correct Header is not provided"})

    


'''
    permission_classes = [IsAuthenticated] 
    
    def get(self,request,format=None):

        if 'Custom-User-Agent' in  request.headers['Custom-User-Agent']==settings.CUSTOMHEADER:
            query = Appointment.objects.all()
            serializer = Appointment_serializer(query,many=True)
            return Response(serializer.data)

        return Response({"Failure": "Correct Header is not provided"})
'''
'''
def post(self, request,format=None):
        if 'Custom-User-Agent' in request.headers and request.headers['Custom-User-Agent']==settings.CUSTOMHEADER:
            #queryset = Appointment.objects.all()
            serializer = Appointment_serializer(data=request.data)
            if serializer.is_valid():
                 serializer.save()
                 return Response(serializer.data,status=status.HTTP_201_CREATED)

            return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

        return Response({"Failure": "Correct Header is not provided"})
'''        