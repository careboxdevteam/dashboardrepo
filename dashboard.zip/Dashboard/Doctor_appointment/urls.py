from .views import DoctorsView, AppointmentView 
from django.urls import path 

urlpatterns = [
    path("docinfo/", DoctorsView.as_view()),
    path("appointment/",AppointmentView.as_view()),
    
]