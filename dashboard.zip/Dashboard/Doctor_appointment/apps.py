from django.apps import AppConfig


class DoctorAppointmentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Doctor_appointment'
