from django.db import models
from django.db.models.fields import BLANK_CHOICE_DASH
from django.utils import timezone
from .validators import validate_file_extension
# Create your models here.

Active_Choices = [
    ('Yes','Yes'),
    ('No','No'),
]

class Doctor(models.Model):
    Id =   models.AutoField(primary_key=True) 
    Name = models.CharField(max_length=1000) 
    Time = models.CharField(max_length=200)
    Date = models.CharField(max_length=200)
    Background = models.CharField(max_length = 2000)
    Doctor_image = models.FileField(upload_to='Doctor/', validators=[validate_file_extension], null=True, blank=True)
    Active = models.CharField(max_length = 10, choices = Active_Choices)
    Designation = models.CharField(max_length=400, default = "")
    #Max_appointment = models.IntegerField()

    def __str__(self):
        return self.Name 
    #def __str__(self):
    #    return str(self.Active)     

class Appointment(models.Model):
    Id = models.AutoField(primary_key=True)
    Patient_name = models.CharField(max_length = 40)
    Mobile_number = models.CharField(max_length = 16, null=False, blank=False)
    Health_Issue = models.TextField(max_length = 50000)
    #Time = models.DateTimeField(default=timezone.now)
    DoctorName = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    Location_Choices = [
    ('Care-Box Outlet','Care-Box Outlet'),
    ]
    Location = models.CharField(max_length = 30, choices = Location_Choices)
    createdAt = models.DateTimeField(auto_now_add=True,null=True)
    
    def __str__(self):
        return self.Patient_name    
    #def __str__(self):
    #    return str(self.Mobile_number)

class Attandance(models.Model):

    
    Name = models.ForeignKey(Doctor,on_delete=models.CASCADE,null=True)
    today_present = models.BooleanField()
    createdAt = models.DateTimeField(auto_now_add=True,null=True)

    def __str__(self):
        return f'{self.Name}'


