from rest_framework import serializers 
from .models import Doctor, Appointment 

class Doctor_serializers(serializers.ModelSerializer):

    class Meta:
        model = Doctor
        fields = '__all__'

class Appointment_serializer(serializers.ModelSerializer):
    class Meta: 
        model = Appointment
        fields = '__all__'
